﻿namespace webApi
{
    public class LoginDto
    {
        public string name { get; set; } = "";
        public string password { get; set; } = "";
    }
}
