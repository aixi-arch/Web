﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using webApi;

namespace webApi
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {

        private readonly LoginResultDto[] users =
        {
            new() { name = "FINERN", role = "管理员", token = "ok", password = "1111" },
            new() { name = "CHARLIE", role = "操作员", token = "ok", password = "2222" },
            new() { name = "User", role = "用户", token = "ok", password = "3333" },
        };


        [HttpPost("login")]
        public IActionResult Login(LoginDto dto)
        {
            Console.WriteLine($"{dto.name}, {dto.password}");
            foreach (var item in users)
            {
                Console.WriteLine($"{item.name}, {item.password}");
                if (item.name == dto.name && item.password == dto.password)
                {
                    return Ok(new LoginResultDto
                    {
                        token = item.token,
                        name = item.name,
                        role = item.role,
                    });
                }
            }
            return Unauthorized();
        }

        [HttpGet("getUsers")]
        public IActionResult GetUsers()
        {
            var result = users.Select(item => new
            {
                item.name,
                item.role
            });

            return Ok(result);
        }

        [HttpGet("getUsersInfo")]
        public IActionResult GetUsersInfo()
        {
            var UsersInfo = users.Select(item => new
            {
                item.name,
                item.password,
                item.role
            });
            return Ok(UsersInfo);
        }
    }
}
