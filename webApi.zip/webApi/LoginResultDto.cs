﻿namespace webApi
{
    public class LoginResultDto
    {
        public string token { get; set; } = "";
        public string name { get; set; } = "";
        public string role { get; set; } = "";
        public string password { get; set; } = "";
    }
}
