﻿namespace LoginDto
{
    public class Class1
    {

    }
}
